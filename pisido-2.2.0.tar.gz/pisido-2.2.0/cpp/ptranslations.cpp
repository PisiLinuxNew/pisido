#include "h/ptranslations.h"

PTranslations::PTranslations()
{
}
