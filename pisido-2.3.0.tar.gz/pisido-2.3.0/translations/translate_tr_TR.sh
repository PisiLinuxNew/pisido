# cd ~/calismalar/pisido
lupdate ../pisido.pro -ts pisido_tr_TR.ts -no-obsolete
linguist pisido_tr_TR.ts
lrelease -compress pisido_tr_TR.ts -qm pisido_tr_TR.qm