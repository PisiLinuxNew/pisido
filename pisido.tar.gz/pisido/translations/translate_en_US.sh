# cd ~/calismalar/pisido
lupdate ../pisido.pro -ts pisido_en_US.ts -no-obsolete
linguist pisido_en_US.ts
lrelease -compress pisido_en_US.ts -qm pisido_en_US.qm